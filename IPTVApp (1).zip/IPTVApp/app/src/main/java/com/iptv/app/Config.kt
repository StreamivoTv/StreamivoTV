package com.iptv.app

object Config {
    // Server URL (aakhir mein "/" nahi). User ko app mein URL nahi dalna padta,
    // sirf username aur password.
    const val BASE_URL = "http://filex.me.uk:8080"
}
