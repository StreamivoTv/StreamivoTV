package com.iptv.app

import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.URLEncoder
import java.net.UnknownHostException
import java.util.concurrent.TimeUnit

private fun JSONObject.str(key: String): String =
    if (isNull(key)) "" else optString(key, "")

object Api {

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()

    private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")

    private suspend fun fetch(url: String): String = withContext(Dispatchers.IO) {
        val req = Request.Builder()
            .url(url)
            .header("User-Agent", "Mozilla/5.0")
            .build()
        client.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) throw IOException("Server ne error diya (${resp.code})")
            resp.body?.string() ?: throw IOException("Server ne khali jawab diya")
        }
    }

    private fun apiUrl(user: String, pass: String, action: String? = null, extra: String = ""): String {
        var u = "${Config.BASE_URL}/player_api.php?username=${enc(user)}&password=${enc(pass)}"
        if (action != null) u += "&action=$action"
        return u + extra
    }

    private fun parseArray(body: String): JSONArray =
        try {
            JSONArray(body)
        } catch (e: Exception) {
            JSONArray()
        }

    // ---------- Login ----------

    suspend fun login(user: String, pass: String): LoginInfo {
        val body = fetch(apiUrl(user, pass))
        val info: JSONObject? = try {
            JSONObject(body).optJSONObject("user_info")
        } catch (e: Exception) {
            null
        }
        if (info == null) throw IOException("Server se sahi jawab nahi aaya. Server URL check karo.")
        if (info.str("auth") != "1") throw IOException("Username ya password galat hai")
        val status = info.str("status")
        if (status.isNotEmpty() && !status.equals("Active", ignoreCase = true)) {
            throw IOException("Account active nahi hai ($status)")
        }
        return LoginInfo(status, info.str("exp_date"))
    }

    // ---------- Categories / Items ----------

    suspend fun categories(kind: Kind, user: String, pass: String): List<Category> =
        withContext(Dispatchers.IO) {
            val action = when (kind) {
                Kind.LIVE -> "get_live_categories"
                Kind.VOD -> "get_vod_categories"
                Kind.SERIES -> "get_series_categories"
            }
            val arr = parseArray(fetch(apiUrl(user, pass, action)))
            val out = ArrayList<Category>(arr.length())
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                out.add(Category(o.str("category_id"), o.str("category_name")))
            }
            out
        }

    suspend fun items(kind: Kind, catId: String, user: String, pass: String): List<Item> =
        withContext(Dispatchers.IO) {
            val action = when (kind) {
                Kind.LIVE -> "get_live_streams"
                Kind.VOD -> "get_vod_streams"
                Kind.SERIES -> "get_series"
            }
            val arr = parseArray(fetch(apiUrl(user, pass, action, "&category_id=${enc(catId)}")))
            val out = ArrayList<Item>(arr.length())
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                if (kind == Kind.SERIES) {
                    out.add(Item(o.str("series_id"), o.str("name"), o.str("cover").ifEmpty { null }, null))
                } else {
                    out.add(
                        Item(
                            o.str("stream_id"),
                            o.str("name"),
                            o.str("stream_icon").ifEmpty { null },
                            o.str("container_extension").ifEmpty { "mp4" }
                        )
                    )
                }
            }
            out
        }

    suspend fun episodes(seriesId: String, user: String, pass: String): List<Episode> =
        withContext(Dispatchers.IO) {
            val body = fetch(apiUrl(user, pass, "get_series_info", "&series_id=${enc(seriesId)}"))
            val raw = JSONObject(body).opt("episodes")
            val groups = ArrayList<Pair<String, JSONArray>>()
            if (raw is JSONObject) {
                val keys = raw.keys().asSequence().sortedBy { it.toIntOrNull() ?: 0 }.toList()
                for (k in keys) {
                    val arr = raw.optJSONArray(k)
                    if (arr != null) groups.add(Pair(k, arr))
                }
            } else if (raw is JSONArray) {
                for (i in 0 until raw.length()) {
                    val arr = raw.optJSONArray(i)
                    if (arr != null) groups.add(Pair((i + 1).toString(), arr))
                }
            }
            val out = ArrayList<Episode>()
            for ((season, arr) in groups) {
                for (i in 0 until arr.length()) {
                    val e = arr.optJSONObject(i) ?: continue
                    val num = e.str("episode_num")
                    val title = e.str("title").ifEmpty { "Episode $num" }
                    out.add(
                        Episode(
                            e.str("id"),
                            "S$season  E$num - $title",
                            e.str("container_extension").ifEmpty { "mp4" }
                        )
                    )
                }
            }
            out
        }

    // ---------- Stream URLs ----------

    fun liveUrl(user: String, pass: String, id: String, ext: String): String =
        "${Config.BASE_URL}/live/${Uri.encode(user)}/${Uri.encode(pass)}/$id.$ext"

    fun vodUrl(user: String, pass: String, id: String, ext: String): String =
        "${Config.BASE_URL}/movie/${Uri.encode(user)}/${Uri.encode(pass)}/$id.$ext"

    fun episodeUrl(user: String, pass: String, id: String, ext: String): String =
        "${Config.BASE_URL}/series/${Uri.encode(user)}/${Uri.encode(pass)}/$id.$ext"

    // ---------- Errors ----------

    fun friendly(e: Exception): String = when (e) {
        is UnknownHostException -> "Server nahi mila. Internet ya server URL check karo."
        is SocketTimeoutException -> "Server ne jawab nahi diya (timeout). Dobara try karo."
        is ConnectException -> "Server se connect nahi ho saka."
        is IllegalArgumentException -> "Server URL sahi nahi hai. Config.kt check karo."
        else -> e.message ?: "Koi masla aa gaya"
    }
}
