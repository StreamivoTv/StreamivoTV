package com.iptv.app

import android.os.Bundle
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.OptIn
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView

@OptIn(UnstableApi::class)
class PlayerActivity : AppCompatActivity() {

    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var tvTitle: TextView

    private var url: String = ""
    private var alt: String? = null
    private var triedAlt = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val u = intent.getStringExtra("url")
        if (u == null) {
            finish()
            return
        }
        url = u
        alt = intent.getStringExtra("alt")

        setContentView(R.layout.activity_player)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        playerView = findViewById(R.id.playerView)
        tvTitle = findViewById(R.id.tvTitle)
        tvTitle.text = intent.getStringExtra("title") ?: ""

        playerView.setControllerVisibilityListener(
            PlayerView.ControllerVisibilityListener { visibility ->
                tvTitle.visibility = visibility
            }
        )

        hideSystemBars()
    }

    private fun hideSystemBars() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.hide(WindowInsetsCompat.Type.systemBars())
        controller.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    override fun onStart() {
        super.onStart()
        if (url.isNotEmpty()) startPlayer(url)
    }

    override fun onStop() {
        super.onStop()
        releasePlayer()
    }

    private fun startPlayer(source: String) {
        releasePlayer()

        val http = DefaultHttpDataSource.Factory()
            .setUserAgent("Mozilla/5.0")
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15000)
            .setReadTimeoutMs(20000)

        val p = ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(this).setDataSourceFactory(http))
            .build()

        p.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                val fallback = alt
                if (fallback != null && !triedAlt) {
                    // .m3u8 na chale to .ts try karo
                    triedAlt = true
                    url = fallback
                    playerView.post { startPlayer(fallback) }
                } else {
                    Toast.makeText(
                        this@PlayerActivity,
                        "Stream nahi chal saka. Server ya internet check karo.",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        })

        playerView.player = p
        p.setMediaItem(MediaItem.fromUri(source))
        p.prepare()
        p.playWhenReady = true
        player = p
    }

    private fun releasePlayer() {
        playerView.player = null
        player?.release()
        player = null
    }
}
