package com.iptv.app

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class LoginActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Pehle se login hai to seedha main screen
        if (Session.user(this) != null && Session.pass(this) != null) {
            goMain()
            return
        }

        setContentView(R.layout.activity_login)

        val etUser = findViewById<TextInputEditText>(R.id.etUser)
        val etPass = findViewById<TextInputEditText>(R.id.etPass)
        val btn = findViewById<MaterialButton>(R.id.btnLogin)
        val progress = findViewById<ProgressBar>(R.id.progress)
        val tvError = findViewById<TextView>(R.id.tvError)

        etPass.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                btn.performClick()
                true
            } else {
                false
            }
        }

        btn.setOnClickListener {
            val u = etUser.text?.toString()?.trim() ?: ""
            val p = etPass.text?.toString()?.trim() ?: ""
            if (u.isEmpty() || p.isEmpty()) {
                tvError.text = "Username aur password dono likho"
                return@setOnClickListener
            }
            tvError.text = ""
            progress.visibility = View.VISIBLE
            btn.isEnabled = false

            lifecycleScope.launch {
                try {
                    val info = Api.login(u, p)
                    Session.save(this@LoginActivity, u, p, formatExpiry(info.expiry))
                    goMain()
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    tvError.text = Api.friendly(e)
                    progress.visibility = View.GONE
                    btn.isEnabled = true
                }
            }
        }
    }

    private fun goMain() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }

    private fun formatExpiry(raw: String): String {
        if (raw.isEmpty()) return "Unlimited"
        val t = raw.toLongOrNull() ?: return raw
        return SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(t * 1000))
    }
}
