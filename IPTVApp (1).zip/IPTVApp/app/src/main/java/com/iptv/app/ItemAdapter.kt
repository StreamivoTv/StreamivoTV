package com.iptv.app

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import coil.load

class ItemAdapter(private val onClick: (Item) -> Unit) :
    RecyclerView.Adapter<ItemAdapter.VH>() {

    private var all: List<Item> = emptyList()
    private var shown: List<Item> = emptyList()
    private var query: String = ""

    fun submit(list: List<Item>) {
        all = list
        refresh()
    }

    fun filter(q: String) {
        query = q.trim()
        refresh()
    }

    @SuppressLint("NotifyDataSetChanged")
    private fun refresh() {
        shown = if (query.isEmpty()) all else all.filter { it.name.contains(query, ignoreCase = true) }
        notifyDataSetChanged()
    }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val name: TextView = v.findViewById(R.id.tvName)
        val icon: ImageView = v.findViewById(R.id.ivIcon)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_channel, parent, false))

    override fun getItemCount(): Int = shown.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = shown[position]
        holder.name.text = item.name
        holder.icon.load(item.icon) {
            placeholder(R.drawable.ic_tv)
            error(R.drawable.ic_tv)
            fallback(R.drawable.ic_tv)
        }
        holder.itemView.setOnClickListener { onClick(item) }
    }
}
