package com.iptv.app

import android.content.Context

object Session {
    private fun prefs(c: Context) = c.getSharedPreferences("iptv_session", Context.MODE_PRIVATE)

    fun save(c: Context, user: String, pass: String, expiry: String) {
        prefs(c).edit()
            .putString("u", user)
            .putString("p", pass)
            .putString("e", expiry)
            .apply()
    }

    fun user(c: Context): String? = prefs(c).getString("u", null)

    fun pass(c: Context): String? = prefs(c).getString("p", null)

    fun expiry(c: Context): String = prefs(c).getString("e", "") ?: ""

    fun clear(c: Context) {
        prefs(c).edit().clear().apply()
    }
}
