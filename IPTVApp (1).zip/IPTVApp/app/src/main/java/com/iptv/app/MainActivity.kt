package com.iptv.app

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.doAfterTextChanged
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.tabs.TabLayout
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var user: String
    private lateinit var pass: String

    private var kind = Kind.LIVE
    private var categories: List<Category> = emptyList()

    private lateinit var adapter: ItemAdapter
    private lateinit var spinner: Spinner
    private lateinit var etSearch: EditText
    private lateinit var progress: ProgressBar
    private lateinit var tvEmpty: TextView

    private var categoriesJob: Job? = null
    private var itemsJob: Job? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val u = Session.user(this)
        val p = Session.pass(this)
        if (u == null || p == null) {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
            return
        }
        user = u
        pass = p

        setContentView(R.layout.activity_main)

        val toolbar = findViewById<MaterialToolbar>(R.id.toolbar)
        toolbar.title = getString(R.string.app_name)
        val expiry = Session.expiry(this)
        if (expiry.isNotEmpty()) toolbar.subtitle = "Expiry: $expiry"
        toolbar.menu.add(0, 1, 0, "Logout")
        toolbar.setOnMenuItemClickListener {
            Session.clear(this)
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
            true
        }

        spinner = findViewById(R.id.spCategory)
        etSearch = findViewById(R.id.etSearch)
        progress = findViewById(R.id.progress)
        tvEmpty = findViewById(R.id.tvEmpty)

        val recycler = findViewById<RecyclerView>(R.id.recycler)
        recycler.layoutManager = LinearLayoutManager(this)
        adapter = ItemAdapter { item -> onItemClick(item) }
        recycler.adapter = adapter

        etSearch.doAfterTextChanged { text ->
            adapter.filter(text?.toString() ?: "")
            tvEmpty.visibility = View.GONE
        }

        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (position in categories.indices) loadItems(categories[position])
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        val tabs = findViewById<TabLayout>(R.id.tabs)
        tabs.addTab(tabs.newTab().setText("Live TV"))
        tabs.addTab(tabs.newTab().setText("Movies"))
        tabs.addTab(tabs.newTab().setText("Series"))
        tabs.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) {
                kind = Kind.values()[tab.position]
                loadCategories()
            }

            override fun onTabUnselected(tab: TabLayout.Tab) {}
            override fun onTabReselected(tab: TabLayout.Tab) {}
        })

        loadCategories()
    }

    private fun setLoading(loading: Boolean) {
        progress.visibility = if (loading) View.VISIBLE else View.GONE
    }

    private fun showEmpty(msg: String) {
        tvEmpty.text = msg
        tvEmpty.visibility = View.VISIBLE
    }

    private fun loadCategories() {
        categoriesJob?.cancel()
        itemsJob?.cancel()
        adapter.submit(emptyList())
        tvEmpty.visibility = View.GONE
        setLoading(true)

        categoriesJob = lifecycleScope.launch {
            try {
                val list = Api.categories(kind, user, pass)
                categories = list
                if (list.isEmpty()) {
                    setLoading(false)
                    spinner.adapter = null
                    showEmpty("Koi category nahi mili")
                    return@launch
                }
                spinner.adapter = ArrayAdapter(
                    this@MainActivity,
                    android.R.layout.simple_spinner_dropdown_item,
                    list.map { it.name }
                )
                // Spinner khud pehli category select kar dega -> loadItems()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                setLoading(false)
                showEmpty(Api.friendly(e))
            }
        }
    }

    private fun loadItems(cat: Category) {
        itemsJob?.cancel()
        tvEmpty.visibility = View.GONE
        setLoading(true)

        itemsJob = lifecycleScope.launch {
            try {
                val list = Api.items(kind, cat.id, user, pass)
                adapter.submit(list)
                setLoading(false)
                if (adapter.itemCount == 0) showEmpty("Is category mein kuch nahi hai")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                setLoading(false)
                showEmpty(Api.friendly(e))
            }
        }
    }

    private fun onItemClick(item: Item) {
        when (kind) {
            Kind.LIVE -> play(
                item.name,
                Api.liveUrl(user, pass, item.id, "m3u8"),
                Api.liveUrl(user, pass, item.id, "ts")
            )
            Kind.VOD -> play(
                item.name,
                Api.vodUrl(user, pass, item.id, item.ext ?: "mp4"),
                null
            )
            Kind.SERIES -> showEpisodes(item)
        }
    }

    private fun play(title: String, url: String, alt: String?) {
        val i = Intent(this, PlayerActivity::class.java)
        i.putExtra("title", title)
        i.putExtra("url", url)
        if (alt != null) i.putExtra("alt", alt)
        startActivity(i)
    }

    private fun showEpisodes(item: Item) {
        setLoading(true)
        lifecycleScope.launch {
            try {
                val eps = Api.episodes(item.id, user, pass)
                setLoading(false)
                if (eps.isEmpty()) {
                    Toast.makeText(this@MainActivity, "Episodes nahi mile", Toast.LENGTH_SHORT).show()
                    return@launch
                }
                AlertDialog.Builder(this@MainActivity)
                    .setTitle(item.name)
                    .setItems(eps.map { it.title }.toTypedArray()) { _, which ->
                        val ep = eps[which]
                        play(ep.title, Api.episodeUrl(user, pass, ep.id, ep.ext), null)
                    }
                    .setNegativeButton("Close", null)
                    .show()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                setLoading(false)
                Toast.makeText(this@MainActivity, Api.friendly(e), Toast.LENGTH_LONG).show()
            }
        }
    }
}
