package com.iptv.app

enum class Kind { LIVE, VOD, SERIES }

data class Category(val id: String, val name: String)

data class Item(val id: String, val name: String, val icon: String?, val ext: String?)

data class Episode(val id: String, val title: String, val ext: String)

data class LoginInfo(val status: String, val expiry: String)
